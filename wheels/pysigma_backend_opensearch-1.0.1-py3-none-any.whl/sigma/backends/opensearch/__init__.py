from .opensearch import OpensearchLuceneBackend

backends = {
    "opensearch": OpensearchLuceneBackend,
}
