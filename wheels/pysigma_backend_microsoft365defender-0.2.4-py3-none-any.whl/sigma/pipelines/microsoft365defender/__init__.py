from .microsoft365defender import microsoft_365_defender_pipeline
# TODO: add all pipelines that should be exposed to the user of your backend in the import statement above.

pipelines = {
    "microsoft_365_defender_pipeline": microsoft_365_defender_pipeline,   # TODO: adapt identifier to something approproiate
}